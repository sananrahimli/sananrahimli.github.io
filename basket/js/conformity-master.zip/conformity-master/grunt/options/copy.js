module.exports = {
    dist: {
        files: {
            '<%= distDir %>conformity.js': 'conformity.js',
        }
    }
};