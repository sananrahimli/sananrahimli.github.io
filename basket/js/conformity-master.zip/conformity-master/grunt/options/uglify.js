module.exports = {
    dist: {
        files: {
            '<%= distDir %>conformity.min.js': 'conformity.js',
        }
    }
};